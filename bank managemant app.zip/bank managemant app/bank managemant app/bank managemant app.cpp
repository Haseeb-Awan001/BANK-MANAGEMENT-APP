#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

/* ---------- COLORS ---------- */
#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define BLUE "\033[34m"
#define CYAN "\033[36m"
#define RESET "\033[0m"

/* ---------- PERMISSIONS ---------- */
#define WITHDRAW 1
#define DEPOSIT 2
#define TRANSFER 4
#define VIP 8

/* ---------- BASE CLASS ---------- */

class Account
{
protected:
    int accountId;
    string name;
    double balance;
    unsigned int permissions;
    vector<double> transactions;

public:

    Account(int id = 0, string n = "", double b = 0, unsigned int p = 0)
    {
        accountId = id;
        name = n;
        balance = b;
        permissions = p;
    }

    int getId()
    {
        return accountId;
    }

    virtual void deposit(double amount) = 0;
    virtual void withdraw(double amount) = 0;

    virtual void show()
    {
        cout << CYAN << "\nAccount ID: " << accountId << RESET << endl;
        cout << "Name: " << name << endl;
        cout << "Balance: " << balance << endl;

        cout << "Transactions:\n";

        for (double t : transactions)
            cout << t << endl;
    }

    virtual void save(ofstream& file) = 0;
    virtual void load(ifstream& file) = 0;

    virtual ~Account() {}
};

/* ---------- SAVINGS ACCOUNT ---------- */

class SavingsAccount :public Account
{
public:

    SavingsAccount(int id = 0, string n = "", double b = 0, unsigned int p = 0)
        :Account(id, n, b, p) {
    }

    void deposit(double amount)
    {
        if (!(permissions & DEPOSIT))
        {
            cout << RED << "Deposit permission denied\n" << RESET;
            return;
        }

        balance += amount;
        transactions.push_back(amount);

        cout << GREEN << "Deposit successful\n" << RESET;
    }

    void withdraw(double amount)
    {
        if (!(permissions & WITHDRAW))
        {
            cout << RED << "Withdraw permission denied\n" << RESET;
            return;
        }

        if (amount > balance)
        {
            cout << RED << "Insufficient balance\n" << RESET;
            return;
        }

        balance -= amount;
        transactions.push_back(-amount);

        cout << GREEN << "Withdraw successful\n" << RESET;
    }

    void save(ofstream& file)
    {
        file << "Savings " << accountId << " " << name << " " << balance << " " << permissions << "\n";

        file << transactions.size() << endl;

        for (double t : transactions)
            file << t << endl;
    }

    void load(ifstream& file)
    {
        int size;

        file >> accountId >> name >> balance >> permissions;
        file >> size;

        for (int i = 0;i < size;i++)
        {
            double t;
            file >> t;
            transactions.push_back(t);
        }
    }
};

/* ---------- CURRENT ACCOUNT ---------- */

class CurrentAccount :public Account
{
public:

    CurrentAccount(int id = 0, string n = "", double b = 0, unsigned int p = 0)
        :Account(id, n, b, p) {
    }

    void deposit(double amount)
    {
        if (!(permissions & DEPOSIT))
        {
            cout << RED << "Deposit permission denied\n" << RESET;
            return;
        }

        balance += amount;
        transactions.push_back(amount);

        cout << GREEN << "Deposit successful\n" << RESET;
    }

    void withdraw(double amount)
    {
        if (!(permissions & WITHDRAW))
        {
            cout << RED << "Withdraw permission denied\n" << RESET;
            return;
        }

        balance -= amount;
        transactions.push_back(-amount);

        cout << GREEN << "Withdraw successful\n" << RESET;
    }

    void save(ofstream& file)
    {
        file << "Current " << accountId << " " << name << " " << balance << " " << permissions << "\n";

        file << transactions.size() << endl;

        for (double t : transactions)
            file << t << endl;
    }

    void load(ifstream& file)
    {
        int size;

        file >> accountId >> name >> balance >> permissions;
        file >> size;

        for (int i = 0;i < size;i++)
        {
            double t;
            file >> t;
            transactions.push_back(t);
        }
    }
};

/* ---------- GLOBAL STORAGE ---------- */

vector<Account*> accounts;

/* ---------- FIND ACCOUNT ---------- */

Account* findAccount(int id)
{
    for (Account* a : accounts)
        if (a->getId() == id)
            return a;

    return nullptr;
}

/* ---------- CREATE ACCOUNT ---------- */

void createAccount()
{
    int type, id;
    string name;
    double balance;
    unsigned int perm;

    cout << YELLOW << "\n1 Savings\n2 Current\n" << RESET;
    cin >> type;

    cout << "Enter ID: ";
    cin >> id;

    cout << "Enter Name: ";
    cin >> name;

    cout << "Enter Balance: ";
    cin >> balance;

    cout << "Permissions (1=Withdraw 2=Deposit 4=Transfer 8=VIP): ";
    cin >> perm;

    Account* acc;

    if (type == 1)
        acc = new SavingsAccount(id, name, balance, perm);
    else
        acc = new CurrentAccount(id, name, balance, perm);

    accounts.push_back(acc);

    cout << GREEN << "Account Created Successfully\n" << RESET;
}

/* ---------- DEPOSIT ---------- */

void depositMoney()
{
    int id;
    double amount;

    cout << "Account ID: ";
    cin >> id;

    Account* acc = findAccount(id);

    if (!acc)
    {
        cout << RED << "Account not found\n" << RESET;
        return;
    }

    cout << "Amount: ";
    cin >> amount;

    acc->deposit(amount);
}

/* ---------- WITHDRAW ---------- */

void withdrawMoney()
{
    int id;
    double amount;

    cout << "Account ID: ";
    cin >> id;

    Account* acc = findAccount(id);

    if (!acc)
    {
        cout << RED << "Account not found\n" << RESET;
        return;
    }

    cout << "Amount: ";
    cin >> amount;

    acc->withdraw(amount);
}

/* ---------- TRANSFER ---------- */

void transferMoney()
{
    int from, to;
    double amount;

    cout << "From ID: ";
    cin >> from;

    cout << "To ID: ";
    cin >> to;

    Account* A = findAccount(from);
    Account* B = findAccount(to);

    if (!A || !B)
    {
        cout << RED << "Account missing\n" << RESET;
        return;
    }

    cout << "Amount: ";
    cin >> amount;

    A->withdraw(amount);
    B->deposit(amount);

    cout << GREEN << "Transfer complete\n" << RESET;
}

/* ---------- SHOW ONE ---------- */

void showAccount()
{
    int id;

    cout << "Enter ID: ";
    cin >> id;

    Account* acc = findAccount(id);

    if (acc)
        acc->show();
    else
        cout << RED << "Account not found\n" << RESET;
}

/* ---------- SHOW ALL ---------- */

void showAllAccounts()
{
    if (accounts.empty())
    {
        cout << RED << "No accounts available\n" << RESET;
        return;
    }

    for (Account* a : accounts)
    {
        a->show();
        cout << "---------------------\n";
    }
}

/* ---------- SAVE ---------- */

void saveFile()
{
    ofstream file("bank.dat");

    file << accounts.size() << endl;

    for (Account* a : accounts)
        a->save(file);

    file.close();

    cout << GREEN << "Data saved\n" << RESET;
}

/* ---------- LOAD ---------- */

void loadFile()
{
    ifstream file("bank.dat");

    if (!file)
    {
        cout << RED << "File not found\n" << RESET;
        return;
    }

    int n;
    file >> n;

    for (int i = 0;i < n;i++)
    {
        string type;

        file >> type;

        Account* acc;

        if (type == "Savings")
            acc = new SavingsAccount();
        else
            acc = new CurrentAccount();

        acc->load(file);

        accounts.push_back(acc);
    }

    cout << GREEN << "Data loaded\n" << RESET;
}

/* ---------- MONTHLY SUMMARY ---------- */

void monthlySummary()
{
    double monthlyTotals[12] = { 0 };

    for (int i = 0;i < 12;i++)
        monthlyTotals[i] = i * 100;

    cout << BLUE << "\nMonthly Summary\n" << RESET;

    for (int i = 0;i < 12;i++)
        cout << "Month " << i + 1 << " : " << monthlyTotals[i] << endl;
}

/* ---------- COMPRESSION DEMO ---------- */

unsigned int encodeTransaction(int type, int amount)
{
    return (type << 28) | amount;
}

void decodeTransaction(unsigned int data)
{
    int type = data >> 28;
    int amount = data & 0x0FFFFFFF;

    cout << "Type: " << type << " Amount: " << amount << endl;
}

/* ---------- MAIN ---------- */

int main()
{
    int choice;

    while (true)
    {
        cout << CYAN << "\n===== BANK MANAGEMENT SYSTEM =====\n" << RESET;

        cout << "1 Create Account\n";
        cout << "2 Deposit\n";
        cout << "3 Withdraw\n";
        cout << "4 Transfer\n";
        cout << "5 Show Account\n";
        cout << "6 Show All Accounts\n";
        cout << "7 Save\n";
        cout << "8 Load\n";
        cout << "9 Monthly Summary\n";
        cout << "10 Compression Demo\n";
        cout << "11 Exit\n";

        cin >> choice;

        if (choice == 1) createAccount();
        else if (choice == 2) depositMoney();
        else if (choice == 3) withdrawMoney();
        else if (choice == 4) transferMoney();
        else if (choice == 5) showAccount();
        else if (choice == 6) showAllAccounts();
        else if (choice == 7) saveFile();
        else if (choice == 8) loadFile();
        else if (choice == 9) monthlySummary();
        else if (choice == 10)
        {
            unsigned int data = encodeTransaction(1, 5000);
            decodeTransaction(data);
        }
        else if (choice == 11)
            break;
    }

    for (Account* a : accounts)
        delete a;

    return 0;
}